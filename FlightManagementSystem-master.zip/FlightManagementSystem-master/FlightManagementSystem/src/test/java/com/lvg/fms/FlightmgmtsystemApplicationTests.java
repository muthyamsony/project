package com.lvg.fms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightmgmtsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
