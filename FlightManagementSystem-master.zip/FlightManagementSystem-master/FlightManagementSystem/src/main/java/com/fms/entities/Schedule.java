package com.fms.entities;



import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Entity
@Table(name="Schedule")
public class Schedule implements Serializable{
	@Id
	@Column(name="scheduled_id")
	private int scheduledid;
	@Column(name="arrivaltime")
	private Date arrivalTime;
	@Column(name="departuretime")
	private Date departureTime;
	
	@OneToOne
	@JoinColumn(name="sourceairport", referencedColumnName="airport_code")
	private Airport sourceairport;
	
	@OneToOne
	@JoinColumn(name="destinationairport", referencedColumnName="airport_code")
	private Airport destinationairport;

	public Schedule() {
	
	}
	
	

	public Schedule(int scheduledid, Date arrivalTime, Date departureTime, Airport sourceairport,
			Airport destinationairport) {
		
		this.scheduledid = scheduledid;
		this.arrivalTime = arrivalTime;
		this.departureTime = departureTime;
		this.sourceairport = sourceairport;
		this.destinationairport = destinationairport;
	}



	public int getScheduledid() {
		return scheduledid;
	}

	public void setScheduledid(int scheduledid) {
		this.scheduledid = scheduledid;
	}

	public Date getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public Date getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}

	public Airport getSourceairport() {
		return sourceairport;
	}

	public void setSourceairport(Airport sourceairport) {
		this.sourceairport = sourceairport;
	}

	public Airport getDestinationairport() {
		return destinationairport;
	}

	public void setDestinationairport(Airport destinationairport) {
		this.destinationairport = destinationairport;
	}
	

	
	
	
}
