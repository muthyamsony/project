package com.fms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fms.entities.Flight;

import com.fms.service.FlightService;


@RestController
@RequestMapping("/flight")
public class FlightController {
	 @Autowired
     FlightService flightservice;

	public void setFlightservice(FlightService flightservice) {
		this.flightservice = flightservice;
	}

	@GetMapping(value="/getflight/{flightnumber}",produces="application/json")
	     public Flight viewFlight(@PathVariable int flightnumber)
	     {
	    	 return flightservice.viewFlight(flightnumber);
	     }
	     
	     @PostMapping(value="/addflight")
	     public Flight addFlight(@RequestBody Flight flight)
	     {
	    	 Flight f= flightservice.addFlight(flight);
	    	 return f;
	     }
	     
	     @GetMapping(value="/getAllFlight",produces="application/json")
	     public List<Flight> viewFlight()
	     {
	    	 return flightservice.viewFlight();
	     }
	     
	     @DeleteMapping("/deleteFlight/{flightnumber}")
	     public String deleteFlight(@PathVariable int flightnumber)
	     {
	    	 flightservice.deleteFlight(flightnumber);
	    	 return "User Details Deleted";
	     }
	     
	     @PutMapping("/updateFlight")
	     public Flight modifyFlight(@RequestBody Flight flight)
	     {
	    	 Flight f=flightservice.modifyFlight(flight);
	    	 return f;
	     }
}
