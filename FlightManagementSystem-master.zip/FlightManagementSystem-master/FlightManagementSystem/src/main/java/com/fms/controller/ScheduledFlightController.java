package com.fms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fms.entities.Flight;
import com.fms.entities.Schedule;
import com.fms.entities.Scheduledflight;

import com.fms.service.ScheduledFlightService;


@RestController
@RequestMapping("/scheduledflight")
public class ScheduledFlightController {
	 @Autowired
     ScheduledFlightService sfservice;
	 
	public void setSfservice(ScheduledFlightService sfservice) {
		this.sfservice = sfservice;
	}

	@GetMapping(value="/getScheduledFlight/{scheduledid}",produces="application/json")
	     public Scheduledflight viewScheduledFlight(@PathVariable int scheduledid)
	     {
	    	 return sfservice.viewScheduledFlight(scheduledid);
	     }
	     
	     @PostMapping(value="/addScheduledFlight")
	     public Scheduledflight addScheduledFlight(@RequestBody Scheduledflight sf)
	     {
	    	 Scheduledflight sfg= sfservice.addScheduledFlight(sf);
	    	 return sfg;
	     }
	     
	     @GetMapping(value="/getAllScheduledflight",produces="application/json")
	     public List<Scheduledflight> viewScheduledFlight()
	     {
	    	 return sfservice.viewScheduledFlight();
	     }
	     
	     @DeleteMapping("/deleteScheduledflight/{scheduledflightid}")
	     public String deleteScheduledFlight(@PathVariable int scheduledid)
	     {
	    	 sfservice.deleteScheduledFlight(scheduledid);
	    	 return "User Details Deleted";
	     }
	     
	     @PutMapping("/modifyScheduledFlight/{scheduleid}")
	     public Scheduledflight modifyScheduledFlight(@RequestBody Flight f, @RequestBody Schedule s, @PathVariable int scheduleid)
	     {
	    	 Scheduledflight sfg=sfservice.modifyScheduledFlight(f,s,scheduleid);
	    	 return sfg;
	     }
}
