package com.fms.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fms.entities.Flight;
import com.fms.entities.Schedule;
import com.fms.entities.Scheduledflight;
import com.fms.repository.ScheduledFlightRepository;
@Service
public class ScheduledFlightService 
{
    @Autowired
    ScheduledFlightRepository fsdao;
    
    public void setFsdao(ScheduledFlightRepository fsdao) { this.fsdao=fsdao; }
    
    @Transactional(readOnly=true)
    public Scheduledflight viewScheduledFlight(int scheduleId)
    {
    	return fsdao.findById(scheduleId).get();
    }
    
    @Transactional(readOnly=true)
    public List<Scheduledflight> viewScheduledFlight()
    {
    	return fsdao.findAll();
    }
    
    @Transactional
    public Scheduledflight addScheduledFlight(Scheduledflight sf)
    {
    	Flight f=new Flight(); f.setFlightNumber(f.getFlightNumber());
    	Schedule s=new Schedule();
    	s.setArrivalTime(s.getArrivalTime());
    	Schedule s1=new Schedule();
    	s1.setDepartureTime(s.getDepartureTime());
    	Schedule s2=new Schedule();
    	s2.setSourceairport(s.getSourceairport());
    	Schedule s3=new Schedule();
    	s3.setDestinationairport(s.getDestinationairport());
    	Scheduledflight sf1=new Scheduledflight();
    	sf1.setAvailableSeats(sf.getAvailableSeats());
    	sf1.setTicketcost(sf.getTicketcost());
    	sf1.setScheduledflightid(sf.getScheduledflightid());
    	Scheduledflight sfg=new Scheduledflight(sf1.getScheduledflightid(),sf.getTicketcost(),s2,s3,s,s1);
    	 return fsdao.save(sfg);
    }
    
    @Transactional
    public Scheduledflight modifyScheduledFlight(Flight f, Schedule s, int scheduleid)
    {
    	Scheduledflight fs=fsdao.findById(scheduleid).get();
    	Scheduledflight sf=new Scheduledflight();
    	if(fs!=null)
    	{
        	s.setArrivalTime(s.getArrivalTime());
        	Schedule s1=new Schedule();
        	s1.setDepartureTime(s.getDepartureTime());
        	Schedule s2=new Schedule();
        	s2.setSourceairport(s.getSourceairport());
        	Schedule s3=new Schedule();
        	s3.setDestinationairport(s.getDestinationairport());
        	fs.setAvailableSeats(sf.getAvailableSeats());
        	fs.setTicketcost(sf.getTicketcost());
        	fs.setScheduledflightid(sf.getScheduledflightid());
        	Scheduledflight sfg=new Scheduledflight(fs.getScheduledflightid(),fs.getTicketcost(),s2,s3,s,s1);
        	return fsdao.save(sfg);
    	}
    	else
    		return null;
    
    }
    
    @Transactional
    public void deleteScheduledFlight(int scheduleId)
    {
    	  fsdao.deleteById(scheduleId);
    }
}
