package com.fms.entities;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="Scheduledflight")
public class Scheduledflight implements Serializable {
	@Id
	@Column(name="scheduledflight_id")
	private int scheduledflightid;
	@Column(name="available_seats")
	private int availableSeats;
	@Column(name="ticket_cost")
	private long ticketcost;
	
	
	@OneToOne
	@JoinColumn(name="scheduledflight_number", referencedColumnName="flight_number")
	private Flight scheduledflight_number;
	
	
	@OneToOne
	@JoinColumn(name="sourceairport", referencedColumnName="sourceairport")
	private Schedule sourceairport;
	
	@OneToOne
	@JoinColumn(name="destinationairport", referencedColumnName="destinationairport")
	private Schedule destinationairport;
	
	@OneToOne
	@JoinColumn(name="arrivaltime", referencedColumnName="arrivaltime")
	private Schedule arrivaltime;
	
	@OneToOne
	@JoinColumn(name="departuretime", referencedColumnName="departuretime")
	private Schedule departuretime;

	public Scheduledflight() {
		
	}

	public Scheduledflight(int scheduledflightid, int availableSeats, long ticketcost, Flight scheduledflight_number,
			Schedule sourceairport, Schedule destinationairport, Schedule arrivaltime, Schedule departuretime) {
		super();
		this.scheduledflightid = scheduledflightid;
		this.availableSeats = availableSeats;
		this.ticketcost = ticketcost;
		this.scheduledflight_number = scheduledflight_number;
		this.sourceairport = sourceairport;
		this.destinationairport = destinationairport;
		this.arrivaltime = arrivaltime;
		this.departuretime = departuretime;
	}

	public Scheduledflight(int scheduledflightid, long ticketcost, Schedule sourceairport, Schedule destinationairport,
			Schedule arrivaltime, Schedule departuretime) {
		super();
		this.scheduledflightid = scheduledflightid;
		this.ticketcost = ticketcost;
		this.sourceairport = sourceairport;
		this.destinationairport = destinationairport;
		this.arrivaltime = arrivaltime;
		this.departuretime = departuretime;
	}

	public int getScheduledflightid() {
		return scheduledflightid;
	}

	public void setScheduledflightid(int scheduledflightid) {
		this.scheduledflightid = scheduledflightid;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public long getTicketcost() {
		return ticketcost;
	}

	public void setTicketcost(long ticketcost) {
		this.ticketcost = ticketcost;
	}

	public Flight getScheduledflight_number() {
		return scheduledflight_number;
	}

	public void setScheduledflight_number(Flight scheduledflight_number) {
		this.scheduledflight_number = scheduledflight_number;
	}

	public Schedule getSourceairport() {
		return sourceairport;
	}

	public void setSourceairport(Schedule sourceairport) {
		this.sourceairport = sourceairport;
	}

	public Schedule getDestinationairport() {
		return destinationairport;
	}

	public void setDestinationairport(Schedule destinationairport) {
		this.destinationairport = destinationairport;
	}

	public Schedule getArrivaltime() {
		return arrivaltime;
	}

	public void setArrivaltime(Schedule arrivaltime) {
		this.arrivaltime = arrivaltime;
	}

	public Schedule getDeparturetime() {
		return departuretime;
	}

	public void setDeparturetime(Schedule departuretime) {
		this.departuretime = departuretime;
	}
	
	
}
